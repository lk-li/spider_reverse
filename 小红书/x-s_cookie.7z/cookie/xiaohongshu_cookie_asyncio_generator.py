# -*- coding: utf-8 -*-
"""
@Auth:
@Data:
@Desc:      先请求代理，然后通过cookies服务生成cookies
@Input:     代理ip
@Output:    可用cookies(JSON)
"""
import asyncio
import json
import math
import random
import urllib.parse
import aiohttp
import time
import hashlib
from loguru import logger
from fake_useragent import UserAgent
import re
import execjs
import aiofiles


class Encrypt(object):
    """
    调用小红书生成cookie的demo函数
    """

    # 这是启动dynamic_cookies_server的默认地址
    server_host = "http://127.0.0.1:27050"

    async def get(self, url, params=None, ret_json=False):
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as rq:

                if ret_json:
                    return await rq.json()
                else:
                    return await rq.text()

    async def post(self, url, json=None, ret_json=False):

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=json) as rq:

                if ret_json:
                    return await rq.json()
                else:
                    return await rq.text()

    async def get_web_id(self) -> dict:
        """
        webId a1 cookie
        :return:
        """

        cookie_info = await self.get(self.server_host + "/gen_web_id", ret_json=True)
        return cookie_info

    async def get_xsign(self, enc_url):
        url = self.server_host + "/gen_xsign"
        url = url + '?url=' + enc_url
        x_sign = await self.get(url)
        return x_sign

    async def get_x_common(self, s, t, a1, count=1):

        url = self.server_host + "/gen_xcommon"
        x_common_data = await self.get(url, params={
            "s": s,
            "t": t,
            "a1": a1,
            "count": count,
        })
        return x_common_data

    async def get_post_data(self, count=1):
        url = self.server_host + "/gen_postData"
        post_data = await self.get(url, params={
            "count": count,
        })
        return post_data

    def get_trace_id(self):
        """
        x-b3-traceid: 7d418fb38e00a81f
        :return:
        """
        tmp = "abcdef0123456789"
        s = ""
        for i in range(16):
            s += tmp[math.floor(16 * random.uniform(0, 1))]

        return s

    async def gen_x_s(self, url, data, a1):
        """
        生成headers 中的 x-t 与 x-s
        """

        param_str = 'url='+url+json.dumps(data).replace(' ','')

        param_str_md5 = hashlib.new('md5', param_str.encode()).hexdigest()

        js_result = execjs.compile(self.js_code).call('Decrypt', param_str_md5, a1)

        return str(js_result['x-t']), js_result['x-s']


class xiaohongshu_cookie_extractor(Encrypt):
    """
    生成小红书动态cookie
    """

    a1 = None
    web_id = None
    # 默认cookies的server地址
    js_encrypt_host = "http://127.0.0.1:28889"

    def __init__(self, proxy, useragent):

        self.user_agent = useragent

        self.proxy = proxy




    def get_headers(self):

        return {
            'authority': 'www.xiaohongshu.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'sec-ch-ua': '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': self.user_agent,
        }


    async def get_xiaohongshu_home_cookie(self):
        # url = "https://www.xiaohongshu.com/"
        url = "https://www.xiaohongshu.com/explore"
        response = {}

        for i in range(20):
            try:

                response = await self.session.post(url, headers=self.get_headers(), proxy=None, timeout=5)
                break

            except Exception as e:
                # self.proxy = await get_valid_proxy(self.rs_pool)
                # logger.info(self.proxy)
                logger.error('这里是cookie生成服务，请求小红书home出错: %s' %e)


        cookies_str = str(response.cookies)

        temp_str = re.findall('Set-Cookie: (.*?);', cookies_str)

        if temp_str != []:
            for i in temp_str:
                dict_key = i.split('=')[0]
                dict_value = i.split('=')[1]
                self.tmp_cookie.update({dict_key: dict_value})


    async def get_user_home_page_cookie(self, count, a1):
        """
        https://www.xiaohongshu.com/fe_api/burdock/v2/shield/profile
        获取cookie
        gid
        gid.sign
        :return:
        """

        # url = "https://www.xiaohongshu.com/fe_api/burdock/v2/shield/profile"
        url = "https://www.xiaohongshu.com/api/sec/v1/shield/webprofile"

        post_data = await self.get_post_data(count=count)

        data = {
            "platform": "Windows",
            "sdkVersion": "3.3.3",
            "svn": "2",
            "profileData": "%s"%post_data
        }
        path = urllib.parse.urlparse(url).path

        x_t, x_s = await self.gen_x_s(path, data, a1)

        x_sign = await self.get_xsign(url)

        x_common = await self.get_x_common(x_s, x_t, self.a1, count)

        referer = "https://www.xiaohongshu.com/"

        headers = {
            'x-t': str(x_t),
            'x-b3-traceid': self.get_trace_id(),
            'user-agent': self.user_agent,
            'x-s-common': x_common,
            "x-sign": x_sign,
            'x-s': x_s,
            'referer': referer,
            "content-type": "application/json;charset=UTF-8"
        }

        response = {}

        for i in range(20):

            try:
                response = await self.session.post(url, headers=headers, data=json.dumps(data).replace(' ',''), cookies=self.tmp_cookie, proxy=None, timeout=5)
                # res = await response.text()
                break

            except Exception as e:
                # self.proxy = await get_valid_proxy(self.rs_pool)

                logger.error('这里是cookie生成服务，请求小红书get_user_home_page_cookie出错: %s' %e)


        cookies_str = str(response.cookies)

        temp_str = re.findall('Set-Cookie: (.*?);', cookies_str)

        if temp_str != []:
            for i in temp_str:
                dict_key = i.split('=')[0]
                dict_value = i.split('=')[1]
                self.tmp_cookie.update({dict_key: dict_value})

    async def get_header_2(self, x_t, x_s, referer):

        x_common = await self.get_x_common(x_s, x_t, self.a1, count=1)

        return {
            'x-t': str(x_t),
            'x-b3-traceid': self.get_trace_id(),
            'user-agent': self.user_agent,
            'x-s': x_s,
            'referer': referer,
            'x-s-common': x_common,
        }

    async def get_login_api_cookie(self, a1):
        """
        获取登录接口web_session
        """

        url = "https://edith.xiaohongshu.com/api/sns/web/v1/login/activate"

        path = urllib.parse.urlparse(url).path

        x_t, x_s = await self.gen_x_s(path, {}, a1)

        referer = "https://www.xiaohongshu.com/"
        headers = await self.get_header_2(x_t, x_s, referer)
        headers["content-type"] = "application/json;charset=UTF-8"

        response = {}

        for i in range(20):
            try:
                response = await self.session.post(url, headers=headers, data="{}", cookies=self.tmp_cookie, proxy=None, timeout=5)

                break

            except Exception as e:

                # self.proxy = await get_valid_proxy(self.rs_pool)

                logger.error('这里是cookie生成服务，请求小红书get_login_api_cookie出错: %s'%e)


        web_session = re.findall("web_session=(.*?);", str(response.cookies))

        if web_session != []:
            web_session = web_session[0]
            self.tmp_cookie.update({'web_session': web_session})
        else:
            logger.error('这里是cookie生成服务，请求小红书get_login_api_cookie响应没有web_session')

    async def get_xiaohongshu_cookie(self):

        """
        请求一系列小红书接口，最后保存在session.cookie里的，就是所需的cookie
        """

        async with aiofiles.open('encryption_parameter_generator.js', 'r', encoding='utf-8') as f:
            self.js_code = await f.read()

        # 临时生成cookie
        self.tmp_cookie = {}

        self.session = aiohttp.ClientSession()

        await self.get_xiaohongshu_home_cookie()

        web_cookies = await self.get_web_id()

        self.a1 = web_cookies["a1"]
        self.web_id = web_cookies["webId"]

        cookie_dict = {
            "webBuild": "2.5.2",
            "xsecappid": "xhs-pc-web",
            "a1": self.a1,
            "webId": self.web_id,
        }

        self.tmp_cookie.update(cookie_dict)

        await self.get_login_api_cookie(self.a1)

        await self.get_user_home_page_cookie(count=1, a1=self.a1)

        await self.get_login_api_cookie(self.a1)

        if self.tmp_cookie.get("acw_tc"):
            self.tmp_cookie.pop("acw_tc")

        if self.tmp_cookie.get('web_session') == None:
            logger.error('生成的cookie中、未包含web_session')
            return None
        elif self.tmp_cookie.get('gid') == None:
            logger.error('生成的cookie中、未包含gid')
            return None

        await self.session.close()

        logger.info(self.tmp_cookie)

        return self.tmp_cookie







if __name__ == '__main__':

    ua = UserAgent().chrome

    proxy = {}

    # 异步的代理格式是这样的  只支持http格式的   不过照样可以请求https的网站
    # 'http://1.1.1.1:5555'

    obj = xiaohongshu_cookie_extractor(proxy, ua)
    asyncio.run(obj.get_xiaohongshu_cookie())
