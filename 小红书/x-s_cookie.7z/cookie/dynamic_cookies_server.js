const express = require('express')
const bodyParser = require('body-parser')
//
const app = express()
const port = 27050
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())

let md5 = require("md5")
let CryptoJS = require("crypto-js");


function a0_0x543e() {
    // var e = ["ctor", "SNmAe", "pow", "q42KWYj", "KfTYt", "qGTfA", "lxWQh", "OcXBH", "hpdTP", "zcTWF", "a2r1ZQo", "userAge", "fDqvJ", "LEdWM", "zDagP", " Array]", "NqdOs", "VZAlG", "wordsTo", "SYlVm", "rable", "_digest", "readFlo", "EXcRE", "kPrkP", "WqGtt", "|2|7|1|", "ikxhY", "charAt", "JApEh", "XefZY", "BVmZI", "bin", "FTPBq", "fCXhO", "DTrbr", "RIxMF", "UJuXg", "lxizm", "IYqgI", "ntwtB", "GHzcl", "VkIPm", "515619okbuSc", "cEEwK", "rOgfA", "UijIk", "xNlWe", "IFKdN", "pdIYK", "vGIuz", "QamKK", "bDqmV", "pngG8yJ", "kuQZq", "yRnhISG", "RNCil", "HSFDJ", "skMPY", "random", "constru", "lPcUs", "mfiMp", "WNyCI", "ZFsux", "HIJKLMN", "OUXTe", "213505TKYkUt", "asStrin", "jGPhw", "ZmserbB", "stringT", "_hh", "rotl", "jNjih", "ezOMc", "12FNdOJJ", "encodin", "yJKwt", "atLE", "IpyPj", "uvnLy", "evgkK", "LHJGH", "UoxZB", "YplIo", "2|3|4|1", "FlYEl", "fromCha", "XhOLE", "sUGSI", "Words", "CcWZI", "yESQQ", "NrAsb", "3|6|4|0", "vrlUV", "bBpCr", "okBzj", "rRmLn", "HiDFY", "Hex", "ABCDEFG", "lECKQ", "string", "iwjwj", "lKcsE", "sNYMU", "length", "test", "YdZUX", "[object", "osyIw", "umick", "DLqdJ", "navigat", "slice", "x3VT16I", " Object", "KbDto", "WIPRR", "zuvxQ", "CNQIo", "nt ", "A4NjFqY", "lUAFM97", "vtfIx", "_ff", "tuAVA", "GUXjn", "vkHbm", "defineP", "jGXbA", "KOsRk", "SNEER", "mUkhF", "ClBGn", "MjzGU", "pPKoa", "WaFXc", "JKodg", "zVOvy", "cvnJR", "uytRs", "oBWZm", "EaGMZ", "lBXvG", "feFUP", "bXlQI", "axfLm", "FJlYN", "yfqjY", "KfnDt", "size", "AkEzs", "45xebJDa", "aQyyJ", "cnLlO", "NJbVq", "pYOkL", "|0|8|6|", "ize", "XrZOl", "get", "LlQOv", "pWobk", "cdefghi", "BLEEu", "_isBuff", "ABLRO", "uyyzO", "iyVYR", "OArwD", "zAgxb", "Illegal", "equEW", "ttIve", "zsDDZ", "roperty", "eqJQh", "lPLEl", "oBytes", "YcAap", "IVjmk", "biuPu", "PKFOs", "Fkqjb", "231rerpKx", "ZcThI", "alert", "isBuffe", "0DSfdik", "YUlOM", "MuQYv", "rCode", "ule", "ggDLb", "ouYkV", "rCZaS", "NgZdN", "nhxOh", "Ojazi", "__esMod", "stringi", "iLsmf", "undefin", "18310JfOQdq", "prototy", "VDMgA", "xyz0123", "u5wPHsO", "QLnvL", "charCod", "String", "FMbVd", "binary", "BOxTP", "azoqU", "floor", "YMxdG", "jklmnop", "uPWLf", "exbUE", "aqFcP", "QHHVj", "72VTYrYU", "EBUCM", "hdBwq", "ZoHKz", "exports", "vyJGG", "2|1|3|5", "_gg", "cVte9UJ", "enumera", "2738060TYhQqS", "push", "RyZJx", "105762wnLMQn", "MLMvF", "vZHUx", "OUXOv", "QYcqT", "Bytes", "bytesTo", "AfphX", "ahauZ", "|0|5|4|", "substr", "VrFqQ", "SbCkH", "split", "IJign", "replace", "utmmN", "mEQOt", "ntvSG", "iFBAC", "VsHtM", "AAJUd", "PnmbA", "wOcza/L", "endian", "qqtiC", "seQxp", "zWRDt", "hECvuRX", "sfGbf", " argume", "|5|0", "Bvk6/7=", "indexOf", "ejKeS", "ZqSNz", "nlHfL", "ZtWnB", "iamspam", "VWXYZab", "hrtXX", "oHQtNP+", "toStrin", "yQVJs", "trZBo", "VigAS", "lNrTk", "MWYyF", "555718BnMYMA", "QrePf", "URHlD", "mtrIN", "GJYEy", "6|7|2|3", "anwja", "JuPPz", "jpJSn", "dniCc", "RFEXt", "lsgpi", "ARRXR", "FmHfQ", "_blocks", "nvthD", "default", "functio", "KblCWi+", "hewPW", "IrUjb", "rniTJ", "13060498XEGIdo", "_ii", "LpfE8xz", "iUalX", "sxyzs", "asBytes", "bAHys", "phugY", "yAgFW", "ZovIz", "vzTOk", "reeyR", "CfrgZ", "OaAcq", "RjgER", "utf8", "configu", "call", "TgopC", "Oyeiu", "UmEFi", "join", "oWysL", "mTYNl", "gkQpp", "ToKTb", "UBTfA", "qrstuvw", "iCeWb", "GMJxV", "bKgFU", "ZCQZb", "PBCYU", "KIVTH", "IWWto", "vhLdz", "cDgfm", "456789+", "UyzSw", "isArray", "eAt", "zmtpi", "OPQRSTU", "7|4|9", "0XTdDgM", "hasOwnP", "lUBwA", "iQVWg", "getTime", "yTjFW", "JQFwK", "QMclx", "zYvVY", "Swijz", "jIkCA", "ble"];
    // return (a0_0x543e = function() {
    //     return e
    // }
    // )()

    return ["UyzSw", "isArray", "eAt", "zmtpi", "OPQRSTU", "7|4|9", "0XTdDgM", "hasOwnP", "lUBwA", "iQVWg", "getTime", "yTjFW", "JQFwK", "QMclx", "zYvVY", "Swijz", "jIkCA", "ble", "ctor", "SNmAe", "pow", "q42KWYj", "KfTYt", "qGTfA", "lxWQh", "OcXBH", "hpdTP", "zcTWF", "a2r1ZQo", "userAge", "fDqvJ", "LEdWM", "zDagP", " Array]", "NqdOs", "VZAlG", "wordsTo", "SYlVm", "rable", "_digest", "readFlo", "EXcRE", "kPrkP", "WqGtt", "|2|7|1|", "ikxhY", "charAt", "JApEh", "XefZY", "BVmZI", "bin", "FTPBq", "fCXhO", "DTrbr", "RIxMF", "UJuXg", "lxizm", "IYqgI", "ntwtB", "GHzcl", "VkIPm", "515619okbuSc", "cEEwK", "rOgfA", "UijIk", "xNlWe", "IFKdN", "pdIYK", "vGIuz", "QamKK", "bDqmV", "pngG8yJ", "kuQZq", "yRnhISG", "RNCil", "HSFDJ", "skMPY", "random", "constru", "lPcUs", "mfiMp", "WNyCI", "ZFsux", "HIJKLMN", "OUXTe", "213505TKYkUt", "asStrin", "jGPhw", "ZmserbB", "stringT", "_hh", "rotl", "jNjih", "ezOMc", "12FNdOJJ", "encodin", "yJKwt", "atLE", "IpyPj", "uvnLy", "evgkK", "LHJGH", "UoxZB", "YplIo", "2|3|4|1", "FlYEl", "fromCha", "XhOLE", "sUGSI", "Words", "CcWZI", "yESQQ", "NrAsb", "3|6|4|0", "vrlUV", "bBpCr", "okBzj", "rRmLn", "HiDFY", "Hex", "ABCDEFG", "lECKQ", "string", "iwjwj", "lKcsE", "sNYMU", "length", "test", "YdZUX", "[object", "osyIw", "umick", "DLqdJ", "navigat", "slice", "x3VT16I", " Object", "KbDto", "WIPRR", "zuvxQ", "CNQIo", "nt ", "A4NjFqY", "lUAFM97", "vtfIx", "_ff", "tuAVA", "GUXjn", "vkHbm", "defineP", "jGXbA", "KOsRk", "SNEER", "mUkhF", "ClBGn", "MjzGU", "pPKoa", "WaFXc", "JKodg", "zVOvy", "cvnJR", "uytRs", "oBWZm", "EaGMZ", "lBXvG", "feFUP", "bXlQI", "axfLm", "FJlYN", "yfqjY", "KfnDt", "size", "AkEzs", "45xebJDa", "aQyyJ", "cnLlO", "NJbVq", "pYOkL", "|0|8|6|", "ize", "XrZOl", "get", "LlQOv", "pWobk", "cdefghi", "BLEEu", "_isBuff", "ABLRO", "uyyzO", "iyVYR", "OArwD", "zAgxb", "Illegal", "equEW", "ttIve", "zsDDZ", "roperty", "eqJQh", "lPLEl", "oBytes", "YcAap", "IVjmk", "biuPu", "PKFOs", "Fkqjb", "231rerpKx", "ZcThI", "alert", "isBuffe", "0DSfdik", "YUlOM", "MuQYv", "rCode", "ule", "ggDLb", "ouYkV", "rCZaS", "NgZdN", "nhxOh", "Ojazi", "__esMod", "stringi", "iLsmf", "undefin", "18310JfOQdq", "prototy", "VDMgA", "xyz0123", "u5wPHsO", "QLnvL", "charCod", "String", "FMbVd", "binary", "BOxTP", "azoqU", "floor", "YMxdG", "jklmnop", "uPWLf", "exbUE", "aqFcP", "QHHVj", "72VTYrYU", "EBUCM", "hdBwq", "ZoHKz", "exports", "vyJGG", "2|1|3|5", "_gg", "cVte9UJ", "enumera", "2738060TYhQqS", "push", "RyZJx", "105762wnLMQn", "MLMvF", "vZHUx", "OUXOv", "QYcqT", "Bytes", "bytesTo", "AfphX", "ahauZ", "|0|5|4|", "substr", "VrFqQ", "SbCkH", "split", "IJign", "replace", "utmmN", "mEQOt", "ntvSG", "iFBAC", "VsHtM", "AAJUd", "PnmbA", "wOcza/L", "endian", "qqtiC", "seQxp", "zWRDt", "hECvuRX", "sfGbf", " argume", "|5|0", "Bvk6/7=", "indexOf", "ejKeS", "ZqSNz", "nlHfL", "ZtWnB", "iamspam", "VWXYZab", "hrtXX", "oHQtNP+", "toStrin", "yQVJs", "trZBo", "VigAS", "lNrTk", "MWYyF", "555718BnMYMA", "QrePf", "URHlD", "mtrIN", "GJYEy", "6|7|2|3", "anwja", "JuPPz", "jpJSn", "dniCc", "RFEXt", "lsgpi", "ARRXR", "FmHfQ", "_blocks", "nvthD", "default", "functio", "KblCWi+", "hewPW", "IrUjb", "rniTJ", "13060498XEGIdo", "_ii", "LpfE8xz", "iUalX", "sxyzs", "asBytes", "bAHys", "phugY", "yAgFW", "ZovIz", "vzTOk", "reeyR", "CfrgZ", "OaAcq", "RjgER", "utf8", "configu", "call", "TgopC", "Oyeiu", "UmEFi", "join", "oWysL", "mTYNl", "gkQpp", "ToKTb", "UBTfA", "qrstuvw", "iCeWb", "GMJxV", "bKgFU", "ZCQZb", "PBCYU", "KIVTH", "IWWto", "vhLdz", "cDgfm", "456789+"]


}

function a0_0x5c27(e, t) {
    var r = a0_0x543e();
    return (a0_0x5c27 = function (e, t) {
            return r[e -= 410]
        }
    )(e, t)
}

function a0_0x4dee00(e, t) {
    return a0_0x5c27(t - -312, e)
}

var crc32 = function (e) {
    var t = 601
        , r = 546
        , n = 410
        , o = 695
        , i = 594
        , a = 761
        , s = 738
        , u = 694
        , l = 689
        , c = 698
        , p = 757
        , d = 551
        , f = 546
        , _ = 769
        , g = 482
        , h = 583
        , m = 443
        , v = 470
        , y = 601
        , b = 762
        , w = 514
        , T = 555
        , S = 549
        , E = 587
        , x = 601
        , k = 474
        , I = 546
        , A = 640
        , O = 501
        , L = {};

    function C(e, t) {
        return a0_0x4dee00(e, t - 331)
    }

    L[C(455, t)] = function (e, t) {
        return e >>> t
    }
        ,
        L[C(453, r)] = function (e, t) {
            return e ^ t
        }
        ,
        L[C(720, 769)] = function (e, t) {
            return e < t
        }
        ,
        L[C(n, 583)] = function (e, t) {
            return e & t
        }
        ,
        L[C(o, i)] = function (e, t) {
            return e < t
        }
    ;
    for (var R = L, P = (C(a, s) + C(768, u) + "1")[C(l, c)]("|"), N = 0; ;) {
        switch (P[N++]) {
            case "0":
                var M = -1;
                continue;
            case "1":
                return R[C(p, t)](R[C(d, f)](-1, M), 0);
            case "2":
                var j = 0;
                continue;
            case "3":
                for (; R[C(780, _)](j, 256); j++) {
                    B = j;
                    for (var D = 0; R[C(843, _)](D, 8); D++)
                        B = R[C(g, h)](1, B) ? 3988292384 ^ R[C(m, t)](B, 1) : R[C(v, y)](B, 1);
                    U[j] = B
                }
                continue;
            case "4":
                for (; R[C(b, 594)](F, e[C(w, T)]); F++)
                    M = R[C(S, f)](R[C(E, x)](M, 8), U[255 & R[C(k, I)](M, e[C(A, 659) + C(O, 431)](F))]);
                continue;
            case "5":
                var F = 0;
                continue;
            case "6":
                var B;
                continue;
            case "7":
                var U = [];
                continue
        }
        break
    }
};
// function getPlatformCode(e) {
//             switch (e) {
//             case "Android":
//                 return PlatformCode.Android;
//             case "iOS":
//                 return PlatformCode.iOS;
//             case "Mac OS":
//                 return PlatformCode.MacOs;
//             case "Linux":
//                 return PlatformCode.Linux;
//             default: // 'Windows'
//                 return PlatformCode.other // 5
//             }
// }
function genRandomString(e) {
    let CHARSET = "abcdefghijklmnopqrstuvwxyz1234567890"
    let r = Array(e);
    let random_val = (function () {
            return CHARSET[Math.floor(36 * Math.random())]
        }
    )
    let tmp = r.fill(void 0)
    return tmp.map(random_val).join("")
}


function gen_web_id() {
    /* gen cookies webId , a1*/
    let platformCode = 5
    let LOCAL_ID_SECRET_VERSION = "0"
    // let timestamp = 1677654683948
    let random_str = genRandomString(30)
    // console.log("random_str : " + random_str)

    let timestamp = (+new Date)

    let enc_str = "".concat((timestamp).toString(16)) + random_str + platformCode + LOCAL_ID_SECRET_VERSION + "000"

    let crc_res = crc32(enc_str)
    // console.log("crc32 : " + crc_res)

    let result = enc_str + crc_res
    result = result.substring(0, 52)
    // console.log("result : " + result)

    let web_id = md5(result).toString()
    let a1 = result
    // console.log(res)
    // console.log(result)

    // webId

    return {
        "webId": web_id,
        "a1": a1,
    }

}



/*
* ori_str 里有个值是canvas 中的值
*
* */


function postData_encrypt(data) {
    /*
    * data : info object
    *
    {
         "x1": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
         "x2": "false",
         "x3": "zh-CN",
         "x4": "24",
         "x5": "8",
         "x6": "24",
         "x7": "Google Inc. (Google),ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)",
         "x8": "8",
         "x9": "1536;864",
         "x10": "1536;864",
         "x11": "-480",
         "x12": "Asia/Shanghai",
         "x13": "true",
         "x14": "true",
         "x15": "true",
         "x16": "false",
         "x17": "true",
         "x18": "un",
         "x19": "Win32",
         "x20": "un",
         "x21": "Chrome PDF Plugin,Chrome PDF Viewer,Native Client",
         "x22": "0ab88f15474a63970784024fa410411b",
         "x23": "false",
         "x24": "false",
         "x25": "false",
         "x26": "false",
         "x27": "false",
         "x28": "0,false,false",
         "x29": "4,7,8",
         "x30": "swf object not loaded",
         "x33": "0",
         "x34": "0",
         "x35": "0",
         "x36": "3",
         "x37": "0|0|0|0|0|0|0|0|0|0",
         "x38": "0|0|0|0|1|0|0|0|0|0|1|0|1|0|1|0",
         "x39": "17",
         "x40": "0",
         "x41": "0",
         "x42": "3.1.0",
         "x43": "0d2c602c",
         "x44": "1677808725949",
         "x45": "connecterror",
         "x46": "false",
         "x31": "124.04347527516074"
    }
    x22 是canvas 1 的签名
    x43 好像也是canvas 的签名, 但是 这两个跟 canvas 相关的浏览器不同值就不同, 可以尝试随机
    x31 每个浏览器都不一样，可以固定也可以尝试 随机
    *
    *
    *
    * */

    // test info
    // let base64_data = "eyJ4MSI6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTAuMC4wLjAgU2FmYXJpLzUzNy4zNiIsIngyIjoiZmFsc2UiLCJ4MyI6InpoLUNOIiwieDQiOiIyNCIsIng1IjoiOCIsIng2IjoiMjQiLCJ4NyI6Ikdvb2dsZSBJbmMuIChHb29nbGUpLEFOR0xFIChHb29nbGUsIFZ1bGthbiAxLjMuMCAoU3dpZnRTaGFkZXIgRGV2aWNlIChTdWJ6ZXJvKSAoMHgwMDAwQzBERSkpLCBTd2lmdFNoYWRlciBkcml2ZXIpIiwieDgiOiI4IiwieDkiOiIxNTM2Ozg2NCIsIngxMCI6IjE1MzY7ODY0IiwieDExIjoiLTQ4MCIsIngxMiI6IkFzaWEvU2hhbmdoYWkiLCJ4MTMiOiJ0cnVlIiwieDE0IjoidHJ1ZSIsIngxNSI6InRydWUiLCJ4MTYiOiJmYWxzZSIsIngxNyI6InRydWUiLCJ4MTgiOiJ1biIsIngxOSI6IldpbjMyIiwieDIwIjoidW4iLCJ4MjEiOiJDaHJvbWUgUERGIFBsdWdpbixDaHJvbWUgUERGIFZpZXdlcixOYXRpdmUgQ2xpZW50IiwieDIyIjoiMGFiODhmMTU0NzRhNjM5NzA3ODQwMjRmYTQxMDQxMWIiLCJ4MjMiOiJmYWxzZSIsIngyNCI6ImZhbHNlIiwieDI1IjoiZmFsc2UiLCJ4MjYiOiJmYWxzZSIsIngyNyI6ImZhbHNlIiwieDI4IjoiMCxmYWxzZSxmYWxzZSIsIngyOSI6IjQsNyw4IiwieDMwIjoic3dmIG9iamVjdCBub3QgbG9hZGVkIiwieDMzIjoiMCIsIngzNCI6IjAiLCJ4MzUiOiIwIiwieDM2IjoiMyIsIngzNyI6IjB8MHwwfDB8MHwwfDB8MHwwfDAiLCJ4MzgiOiIwfDB8MHwwfDF8MHwwfDB8MHwwfDF8MHwxfDB8MXwwIiwieDM5IjoiMTciLCJ4NDAiOiIwIiwieDQxIjoiMCIsIng0MiI6IjMuMS4wIiwieDQzIjoiMGQyYzYwMmMiLCJ4NDQiOiIxNjc3ODA4NzI1OTQ5IiwieDQ1IjoiY29ubmVjdGVycm9yIiwieDQ2IjoiZmFsc2UiLCJ4MzEiOiIxMjQuMDQzNDc1Mjc1MTYwNzQifQ=="
    // let ori_result = "c058828ff50a429ae90a3cdb598d3a5945dc32e1a032b897fff9e445c22f30c0290d1f1e0d3b8c473ea5da909cdbb65f8da7eea6a0b5d138206c6335112f40a5f40cc617b9326f1edfc0579e58e45802ab7b3e3e1bde7ab9fe0c6ddd08c34d0d9e5ff9659893314b4cafaa48267975633d2c8f7eab5e886ee62d3c373cac9e0590fa00422e7a9737831baed6e04937e5c5765a74cdb6b485bd1e45d89f29b6e049454845f5bf879a92c34cb6084b251996c1beda50127c43034faa133df7ec64fddff0398daf98bcb1a9cd814a2387bf5f040f2e7b740ceab9458a30ec125ea7db6320cfaac0e4132f5e0f35d9c68250dc925f1cfbb4d28a2f57d3149c7f24cd28756dbab8db38aaf5259a593caca2925eef25950a1ba8d4654e97bf36fc5b1a1315bb625ce54773081399cf2df374b956392961776287faad1009a63e9b240c9a91e859d3ec93aa31f3ba80a439d6f675fa112cad22dc928de6603facd5332696119ba1ce7013c9f0860ade6bca641bc84d530ec6110873b6d74b1e72ed13980977e24787fbb3a4b396aa6c6aeb417c395633dedb718b02d765679bad368db644904a76e1bdd25f5a29f6ac891f97c4ec71cd6f175f9f650d27553b1b03064a0ac12868801ddc1459cb8cf4ab57971dbec9b413cf32397a404a592024a948eedb948bfff3eb8a41651fc23a0bca54db88bc9559f407fe28561a479c103b4b89e197a5764e2a04f5077ae2708fc729bcaf2a27abd4bd1d8895b5a41cbfa4b577bead725c76dccc2df9e77fa5381abc9e7d0f0afb8e3cb5f088f5c239c1f4f3f923651cb59dac14fcc05d48836eef7b11a97d504e64bd33a8370bc4efbb137aa65c8eaf0c92fb09d9e2c6acdb157dd3a0fae7d5669156dd8360e27390e501444ab580af8c59e91aed5435a9e23518cb12c1f399c59a8a8154c6095c445d0402eb5435a9e23518cb129d50e995cddd5751f0512fc6f9728ac55042e1361a6eebde099688007b76852afde10b58d55504c0232db59789fef741994ba3e044b7c56e47c78f542f40754cea044fb4e21df6da0a8c76c87d1df16c766d1a7f3e55fedbf63f11182ce2723a7d0f0afb8e3cb5f074ddc95dc563196dcd292b05231c2b524aee74937a073a6bcaa836a0a185c0c84b831cb9a7d11731b98666ffc40cef5f7d0f0afb8e3cb5f00fc6f4127cb68270cd292b05231c2b524dcff5eb387bb4633d0f644a20ce307fc8663175ece21f2e7d0f0afb8e3cb5f0073db3eb941a2d0f24186f19fb8cf762a7fa5257279be35face6ec0a9f4335b1d2d1b9dfac23a9acd550d9176d7f2a5f42176884d3e6730eef6b67f4036b69000b56b4ea83029f517855bf4c058d6489e1c7accbb9ed21d822d3c2d14c03381d6f164f65a1a9b4be88ab10486a1cc11ecc9c763203d6688814865052ff7c7108402b3214cc521dec402b3214cc521deca0e319d6c26bcd466ff0e9d43e364710402b3214cc521dec8826d9b01fea7453402b3214cc521deccbb6c038daab98ce95a3a54421c8eabb247891f9fc452daec0cbdc405a9e898b1369c975fb35daedfa0afff8a81a3c3d6de0d28a099b86f3a1efb9d30116e814e3da089657b31011ace3f1d03e6ed27d8cb233360cf917c69283c202851d1954b44b348bb5763932ec00b45efed9a3c6e3e9b402233361450beb0a7c4e8e8433e4b15ea5cb7a1383498adf137e840dfe43b21e9ad6342da6e0545a3b0bee604f4edf76b114e86f3f92c34cb6084b25194aebd3caeb8b883017e333a659de8cc4b221c1cf327c392c1e2bf57ef50e0eb2715ec53766553245"

    let string_data = JSON.stringify(data)

    let base_data = btoa(string_data)
    const secretKey = "zbp30y86"
    let encrypt_obj = CryptoJS.DES.encrypt(base_data, CryptoJS.enc.Utf8.parse(secretKey), {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.ZeroPadding
    })
    let enc_result = encrypt_obj.ciphertext.toString()
    return enc_result
}


function x_sign_gen(url, params, paramsSerializer) {
    // paramsSerializer 是function

    // var r, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : DEFAULT_SIGN_VERSION,
    //         o = e.url, // '//www.xiaohongshu.com/fe_api/burdock/v2/shield/profile'
    //         i = void 0 === o ? "" : o,
    //         a = e.params,
    //         s = e.paramsSerializer;
    //     return i = slice_default()(i).call(
    //         i,
    //         index_of_default()(i).call(
    //             i, DEFAULT_SIGN_API_PATH
    //         ), i.length),
    //     n === DEFAULT_SIGN_VERSION ? concat_default()(r = "".concat(n)).call(r, md5_default()(t(i, a, s) + SECRET_KEY)) : ""


    // url,params,paramsSerializer
    function i(e) {
        return "[object Array]" === o.call(e)
    }

    let decide_util = {

        isArrayBuffer: function (e) {
            return "[object ArrayBuffer]" === o.call(e)
        },
        isBuffer: function (e) {
            return null !== e && !a(e) && null !== e.constructor && !a(e.constructor) && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
        },
        isFormData: function (e) {
            return "undefined" != typeof FormData && e instanceof FormData
        },
        isArrayBufferView: function (e) {
            return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && e.buffer instanceof ArrayBuffer
        },
        isString: function (e) {
            return "string" == typeof e
        },
        isNumber: function (e) {
            return "number" == typeof e
        },
        isDate: function (e) {
            return "[object Date]" === o.call(e)
        },
        isFile: function (e) {
            return "[object File]" === o.call(e)
        },
        isBlob: function (e) {
            return "[object Blob]" === o.call(e)
        },
        isStream: function (e) {
            return s(e) && u(e.pipe)
        },
        isURLSearchParams: function (e) {
            return "undefined" != typeof URLSearchParams && e instanceof URLSearchParams
        },
        isStandardBrowserEnv: function () {
            return ("undefined" == typeof navigator || "ReactNative" !== navigator.product && "NativeScript" !== navigator.product && "NS" !== navigator.product) && ("undefined" != typeof window && "undefined" != typeof document)
        },
        forEach: function (e, t) {
            if (null != e)
                if ("object" != typeof e && (e = [e]),
                    i(e))
                    for (var r = 0, n = e.length; r < n; r++)
                        t.call(null, e[r], r, e);
                else
                    for (var o in e)
                        Object.prototype.hasOwnProperty.call(e, o) && t.call(null, e[o], o, e)
        },
        trim: function (e) {
            return e.replace(/^\s*/, "").replace(/\s*$/, "")
        }
    }

    function o(e) {
        return encodeURIComponent(e).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
    }

    function merge_item(e, t, r) {
        /* params 解析
        *  e : url
        *  t : params
        *  r : params stringify func
        * */

        if (!t)
            return e;
        var i;
        if (r)
            i = r(t);
        else if (decide_util.isURLSearchParams(t))
            i = t.toString();
        else {
            var a = [];
            decide_util.forEach(t, (function (e, t) {
                    null != e && (decide_util.isArray(e) ? t += "[]" : e = [e],
                        decide_util.forEach(e, (function (e) {
                                decide_util.isDate(e) ? e = e.toISOString() : decide_util.isObject(e) && (e = JSON.stringify(e)),
                                    a.push(o(t) + "=" + o(e))
                            }
                        )))
                }
            )),
                i = a.join("&")
        }
        if (i) {
            var s = e.indexOf("#");
            -1 !== s && (e = e.slice(0, s)),
                e += (-1 === e.indexOf("?") ? "?" : "&") + i
        }
        return e
    }

    let salt = "WSUDD"

    // 小红书web 目前看到只有这个需要裁减url , 其实就是 url path
    let tmp_url = "/fe_api/";


    let url_path = url.slice(url.indexOf(tmp_url), url.length)
    console.log(url_path)
    let enc_str = merge_item(url_path, params, paramsSerializer)
    let enc_ret = CryptoJS.MD5(enc_str + salt).toString()
    let ret = "X" + enc_ret
    console.log(ret)
    return ret


}

function gen_x8(fid_info_obj) {
    function RC4_encrypt(d, b) {
        let c, a = [], e = 0, f = "";
        for (let d = 0; d < 256; d++) {
            a[d] = d;
        }
        for (let b = 0; b < 256; b++) {
            e = (e + a[b] + d.charCodeAt(b % d.length)) % 256, c = a[b], a[b] = a[e], a[e] = c;
        }
        let t = 0;
        e = 0;
        for (let d = 0; d < b.length; d++) {
            t = (t + 1) % 256, e = (e + a[t]) % 256, c = a[t], a[t] = a[e], a[e] = c, f += String.fromCharCode(b.charCodeAt(d) ^ a[(a[t] + a[e]) % 256]);
        }
        return f;
    }

    function encode_data_to_list(encode_data) {
        /* encodeURIComponent data 转为num list*/
        let tag = 0;
        let tmp_list = [];
        let num_list = []
        for (let i = 0; i < encode_data.length; i++) {

            let tmp_char = encode_data[i]
            if (tmp_char === "%") {
                tag = 1
                continue
            }

            if (tag) {
                if (tmp_list.length < 2) {
                    tmp_list.push(tmp_char)

                    if (tmp_list.length == 2) {
                        num_list.push(parseInt(tmp_list.join(""), 16))
                        tmp_list = []
                        tag = 0
                    }

                }
            } else {
                num_list.push(tmp_char.charCodeAt())
            }

        }
        return num_list
    }

    function garbled_decode(garbledList) {
        let g_len = garbledList.length
        let yu_num = g_len % 3
        let for_num = g_len - yu_num
        let result = ""
        const decode_str = "ZmserbBoHQtNP+wOcza/LpngG8yJq42KWYj0DSfdikx3VT16IlUAFM97hECvuRX5"
        for (let i = 0; i < for_num; i += 3) {
            let charCodeAtNum0 = garbledList[i];
            let charCodeAtNum1 = garbledList[i + 1];
            let charCodeAtNum2 = garbledList[i + 2];

            let p0 = charCodeAtNum0 << 16;
            let p1 = charCodeAtNum1 << 8;
            let p2 = charCodeAtNum2;

            let num_0 = (p0 & 16711680);
            let num_1 = (p1 & 65280);
            let num_2 = p2 & 255;

            let tmps = num_0 + num_1 + num_2
            let str1 = decode_str[(tmps >> 18) & 63];
            let str2 = decode_str[(tmps >> 12) & 63];

            let str3 = decode_str[(tmps >> 6) & 63];
            let str4 = decode_str[tmps & 63];
            result += str1 + str2 + str3 + str4;
        }
        let end_str = ""
        // 后缀有3种可能
        if (yu_num === 1) {
            // 16383
            let last_one = decode_str[garbledList[g_len - 1] >> 2]
            let last_two = decode_str[(garbledList[g_len - 1] << 4) & 63]
            end_str = last_one + last_two + "=="

        } else if (yu_num === 2) {

            let index = g_len - yu_num
            let last_one = garbledList[index] << 8
            let two_num = garbledList[g_len - 1]
            let word_num = last_one + two_num
            let first = decode_str[word_num >> 10]
            let sec = decode_str[(word_num >> 4) & 63]
            let three = decode_str[(word_num << 2) & 63]
            end_str = first + sec + three + "="
        }
        if (end_str.length > 0) {
            result += end_str
        }
        return result
    }

    let salt = "xhswebmplfbt"
    let data_str = JSON.stringify(fid_info_obj)
    let garbled_str = RC4_encrypt(salt, data_str)
    let url_encode_str = encodeURIComponent(garbled_str)
    let num_list = encode_data_to_list(url_encode_str)
    let result = garbled_decode(num_list)
    return result
}

function x_s_common_gen(s, t, a1, count = 0) {
    /*
    *  "s0": 5,
         "s1": "",
         "x0": "1",
         "x1": "3.0.0",
         "x2": "Windows",
         "x3": "xhs-pc-web",
         "x4": "1.2.1",
         "x5": "186a5339d088hf49662z5igdlrpf7nvzkecakq2r250000206201",    cookie "a1"
         "x6": 1677832055642,  x-t
         "x7": "sBVB0jkUsjMpsgvlsg9WsBOv0gO61BciZj1l02FCsj93",    x-s
         * x8 -> cookie b1  vmp 里生成
         "x8": "I38rHdgsjopgIvesdVwgIC+oIELmBZ5e3VwXLgFTIxS3bqwErFeexd0ekncAzMFYnqthIhJeDfMDKutRI3KsYorWHPtGrbV0P9WfIi/eWc6eYqtyQApPI37ekmR12MuYIhOeDfdsjBM5Hqwl2qt5B0DoIx+PGDi/sVtkIxdsxuwr4qtiIkrOIi/skccxICLdI3Oe0Vtl29qqpIJsdp5ejVwMIiesiuwgNutQsqwj+zKekZh4ICYUIhHl/PwgGutTIvYnoFKexuthICAe3VtBIhlNIklLgg6sfn8SbedsjutQrrAefIH0goJeYWLOIxgeDPtpIEeejutTmprFt7LZIx5sTVwfZDos3aqyIkhaIkhZ89quIxhnqzQgIkIfaPtfI3YRP73e0W==",
         "x9": 782386596,  mcr( x6 + x7 + x8)
         "x10": 11  getSigCount(u && l || c)
    *
    * */


    var mcr = function (e) {
        var t = 1
            , r = 169
            , n = 71
            , o = 141
            , i = 43
            , a = 75
            , s = 64
            , u = 113
            , l = 69
            , c = 233
            , p = 19
            , d = 166
            , f = 131
            , _ = 91
            , g = 231
            , h = 170
            , m = 232
            , v = 212
            , y = 184
            , b = 97
            , w = 101
            , T = 170
            , S = 48
            , E = 362
            , x = 886
            , k = 781
            , I = 865
            , A = 639
            , O = 501
            , L = 713
            , C = 855
            , R = 776
            , P = 883
            , N = 667
            , M = 664
            , j = 817
            , D = 824
            , F = 711
            , B = 667
            , U = 761
            , H = 921
            , W = 624
            , $ = 713
            , V = 859
            , G = 911
            , z = 1050
            , q = 689
            , Y = 522
            , Z = 610
            , K = 568
            , X = 291;

        function J(e, t) {
            return a0_0x4dee00(t, e - -X)
        }

        var Q = {};
        Q[J(-29, -21)] = function (e, t) {
            return e === t
        }
            ,
            Q[J(t, r)] = J(-n, -183),
            Q[J(-o, -i)] = function (e, t) {
                return e < t
            }
            ,
            Q[J(a, s)] = function (e, t) {
                return e ^ t
            }
            ,
            Q[J(-u, -112)] = function (e, t) {
                return e & t
            }
            ,
            Q[J(-l, -c)] = function (e, t) {
                return e >>> t
            }
            ,
            Q[J(-p, -d)] = function (e, t) {
                return e ^ t
            }
            ,
            Q[J(f, 279)] = function (e, t) {
                return e & t
            }
            ,
            Q[J(-_, -g)] = function (e, t) {
                return e >>> t
            }
            ,
            Q[J(-h, -m)] = function (e, t) {
                return e ^ t
            }
            ,
            Q[J(-123, -v)] = function (e, t) {
                return e >>> t
            }
            ,
            Q[J(-y, -b)] = function (e, t) {
                return e >>> t
            }
        ;
        for (var ee, te, re = Q, ne = 3988292384, oe = 256, ie = []; oe--; ie[oe] = re[J(-_, -w)](ee, 0))
            for (te = 8,
                     ee = oe; te--;)
                ee = 1 & ee ? re[J(-T, -S)](re[J(-123, -34)](ee, 1), ne) : re[J(-184, -E)](ee, 1);
        return function (e) {
            var t = 780;

            function r(e, r) {
                return J(e - t, r)
            }

            if (re[r(751, x)](typeof e, re[r(k, I)])) {
                for (var n = 0, o = -1; re[r(A, O)](n, e[r(L, 793)]); ++n)
                    o = re[r(C, R)](ie[re[r(855, P)](re[r(N, M)](o, 255), e[r(j, D) + r(589, 545)](n))], re[r(F, B)](o, 8));
                return re[r(U, H)](-1 ^ o, ne)
            }
            for (n = 0,
                     o = -1; re[r(A, W)](n, e[r($, V)]); ++n)
                o = ie[re[r(G, z)](o, 255) ^ e[n]] ^ re[r(q, Y)](o, 8);
            return re[r(Z, K)](-1 ^ o, ne)
        }
    }()

    // 修改后的base64 表
    let lookup = ['Z', 'm', 's', 'e', 'r', 'b', 'B', 'o', 'H', 'Q', 't', 'N', 'P', '+', 'w', 'O', 'c', 'z', 'a', '/', 'L', 'p', 'n', 'g', 'G', '8', 'y', 'J', 'q', '4', '2', 'K', 'W', 'Y', 'j', '0', 'D', 'S', 'f', 'd', 'i', 'k', 'x', '3', 'V', 'T', '1', '6', 'I', 'l', 'U', 'A', 'F', 'M', '9', '7', 'h', 'E', 'C', 'v', 'u', 'R', 'X', '5']

    function encodeUtf8(e) {
        for (var t = 14, r = 44, n = 8, o = 97, i = 379, a = 42, s = 97, u = 53, l = 36, c = 138, p = 163, d = 193, f = 111, _ = 127, g = 87, h = 141, m = 158, v = 241, y = {
            WaFXc: function (e, t) {
                return e < t
            },
            cDgfm: function (e, t) {
                return e === t
            },
            BLEEu: function (e, t) {
                return e + t
            },
            JKodg: function (e, t) {
                return e + t
            },
            PnmbA: function (e, t, r) {
                return e(t, r)
            }
        }, b = encodeURIComponent(e), w = [], T = 0; y[k(t, r)](T, b[k(-17, n)]); T++) {
            var S = b[k(-o, 75)](T);
            if (y[k(219, i)](S, "%")) {
                var E = y[k(a, 139)](b[k(-s, u)](y[k(42, -l)](T, 1)), b[k(-s, -c)](y[k(15, p)](T, 2)))
                    , x = y[k(135, 28)](parseInt, E, 16);
                w[k(111, d)](x),
                    T += 2
            } else
                w[k(f, _)](S[k(g, -40) + k(-h, -m)](0))
        }

        function k(e, t) {
            return a0_0x4dee00(t, e - -v)
        }

        return w
    }

    function tripletToBase64(e) {
        var t = 319
            , r = 153
            , n = 216
            , o = 80
            , i = 410
            , a = 465
            , s = 396
            , u = 367
            , l = 228
            , c = 486
            , p = 542
            , d = 319
            , f = 216
            , _ = 308
            , g = 410
            , h = 273
            , m = 418
            , v = 414
            , y = 55
            , b = {};

        function w(e, t) {
            return a0_0x4dee00(t, e - y)
        }

        b[w(251, 107)] = function (e, t) {
            return e + t
        }
            ,
            b[w(t, r)] = function (e, t) {
                return e + t
            }
            ,
            b[w(n, o)] = function (e, t) {
                return e + t
            }
            ,
            b[w(i, a)] = function (e, t) {
                return e & t
            }
            ,
            b[w(459, s)] = function (e, t) {
                return e >> t
            }
            ,
            b[w(u, l)] = function (e, t) {
                return e & t
            }
            ,
            b[w(c, p)] = function (e, t) {
                return e >> t
            }
        ;
        var T = b;
        return T[w(251, 316)](T[w(d, 143)](T[w(f, _)](lookup[T[w(g, h)](T[w(459, m)](e, 18), 63)], lookup[T[w(367, 337)](T[w(486, 553)](e, 12), 63)]), lookup[e >> 6 & 63]), lookup[T[w(367, v)](e, 63)])
    }

    function encodeChunk(e, t, r) {
        var n, o = 239, i = 223, a = 401, s = 331, u = 401, l = 168, c = 333, p = 300, d = 365, f = 454, _ = 293,
            g = 197, h = 365, m = 160, v = 419, y = 67, b = 512, w = {
                cnLlO: function (e, t) {
                    return e < t
                },
                QMclx: function (e, t) {
                    return e + t
                },
                ZoHKz: function (e, t) {
                    return e & t
                },
                WNyCI: function (e, t) {
                    return e << t
                },
                BVmZI: function (e, t) {
                    return e & t
                },
                lECKQ: function (e, t) {
                    return e + t
                },
                pdIYK: function (e, t) {
                    return e(t)
                }
            };

        function T(e, t) {
            return a0_0x4dee00(t, e - -b)
        }

        for (var S = [], E = t; w[T(-o, -i)](E, r); E += 3)
            n = w[T(-a, -s)](w[T(-u, -248)](w[T(-l, -196)](w[T(-c, -p)](e[E], 16), 16711680), w[T(-d, -f)](e[w[T(-_, -g)](E, 1)] << 8, 65280)), w[T(-h, -204)](e[E + 2], 255)),
                S[T(-m, -302)](w[T(-347, -v)](tripletToBase64, n));
        return S[T(-y, -230)]("")
    }

    function b64Encode(e) {
        var t = 43
            , r = 2
            , n = 405
            , o = 235
            , i = 196
            , a = 373
            , s = 208
            , u = 168
            , l = 284
            , c = 223
            , p = 339
            , d = 196
            , f = 63
            , _ = 91
            , g = 149
            , h = 26
            , m = 37
            , v = 302
            , y = 68
            , b = 271
            , w = 155
            , T = 136
            , S = 33
            , E = 155
            , x = 11
            , k = 442
            , I = 301
            , A = 138
            , O = 80
            , L = 34
            , C = 21
            , R = 370
            , P = 105
            , N = 96
            , M = 100
            , j = 106
            , D = 68
            , F = 304
            , B = {
            qqtiC: H(178, 67) + H(-t, -r) + "5",
            QHHVj: function (e, t) {
                return e === t
            },
            sxyzs: function (e, t) {
                return e >> t
            },
            IVjmk: function (e, t) {
                return e & t
            },
            KbDto: function (e, t) {
                return e + t
            },
            kuQZq: function (e, t) {
                return e << t
            },
            WqGtt: function (e, t) {
                return e - t
            },
            vrlUV: function (e, t) {
                return e + t
            },
            VZAlG: function (e, t) {
                return e % t
            },
            OcXBH: function (e, t) {
                return e - t
            },
            KOsRk: function (e, t, r, n) {
                return e(t, r, n)
            },
            tuAVA: function (e, t) {
                return e > t
            },
            gkQpp: function (e, t) {
                return e + t
            }
        }
            , U = B[H(n, o)][H(81, 223)]("|");

        function H(e, t) {
            return a0_0x4dee00(e, t - -144)
        }

        for (var W = 0; ;) {
            switch (U[W++]) {
                case "0":
                    var $ = [];
                    continue;
                case "1":
                    B[H(69, i)](z, 1) ? (G = e[q - 1],
                        $[H(a, s)](lookup[B[H(u, l)](G, 2)] + lookup[B[H(c, 155)](G << 4, 63)] + "==")) : B[H(p, d)](z, 2) && (G = B[H(-f, _)](B[H(g, h)](e[B[H(m, -3)](q, 2)], 8), e[B[H(91, -3)](q, 1)]),
                        $[H(v, 208)](B[H(142, y)](B[H(102, y)](lookup[B[H(b, l)](G, 10)], lookup[B[H(u, w)](B[H(T, 284)](G, 4), 63)]) + lookup[B[H(S, E)](G << 2, 63)], "=")));
                    continue;
                case "2":
                    var V = 16383;
                    continue;
                case "3":
                    var G;
                    continue;
                case "4":
                    var z = B[H(-T, -x)](q, 3);
                    continue;
                case "5":
                    return $[H(k, I)]("");
                case "6":
                    var q = e[H(A, O)];
                    continue;
                case "7":
                    for (var Y = 0, Z = B[H(L, -C)](q, z); Y < Z; Y += V)
                        $[H(R, s)](B[H(76, P)](encodeChunk, e, Y, B[H(N, M)](B[H(-j, D)](Y, V), Z) ? Z : B[H(427, F)](Y, V)));
                    continue
            }
            break
        }
    }

    function gen_sign() {
        // 0d2c602c 生成
        let m_list = ['\r', '`', '­', '\x16']
        let res = []


        let tmp_char = m_list[0].charCodeAt()
        let mm = tmp_char & 255
        if (mm < 16) {
            res.push("0")
        }
        res.push(Number(mm), 16)
        // ","
        res.push(Number(44).toString(16))

        tmp_char = m_list[1].charCodeAt()
        res.push(Number(tmp_char).toString(16))
        res.push(Number(44).toString(16))
        return res.join("")

    }

    // 第二个指纹字典 用于加密生成 第一个dict的 x8
    let fid_info_2 = {
        "x33": "0",
        "x34": "0",
        "x35": "0",
        // "x36": "3",  // 固定
        "x36": "1",  // 固定
        "x37": "0|0|0|0|0|0|0|0|0|0",
        "x38": "0|0|0|0|1|0|0|0|0|0|1|0|1|0|1|0",
        "x39": Number(count).toString(), // profile 提交的次数 本地存储
        "x42": "3.1.0",
        "x43": "0d2c602c", // 固定 gen_sign()
        "x44": new Date().getTime().toString(),
        "x45": "connecterror",
        "x46": "false"
    }

    let x8 = gen_x8(fid_info_2)
    let data = {
        "s0": 5,
        "s1": "",
        "x0": "1",
        "x1": "3.1.0",
        "x2": "Windows",
        "x3": "xhs-pc-web",
        "x4": "1.2.3",
        // "x5": "186a5339d088hf49662z5igdlrpf7nvzkecakq2r250000206201",
        "x5": a1,
        "x6": parseInt(t),
        "x7": s,
        "x8": x8,
        "x9": mcr(t + s + x8),
        "x10": parseInt(count) // profile 提交的次数,本地记录
    }

    return b64Encode(encodeUtf8(JSON.stringify(data)))
}

function gen_postData(count=0) {
    let post_data_json = {
            "x1": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
            "x2": "false",
            "x3": "zh-CN",
            "x4": "24",
            "x5": "8",
            "x6": "24",
            "x7": "Google Inc. (Google),ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)",
            "x8": "8",
            "x9": "1536;864",
            "x10": "1536;864",
            "x11": "-480",
            "x12": "Asia/Shanghai",
            "x13": "true",
            "x14": "true",
            "x15": "true",
            "x16": "false",
            "x17": "true",
            "x18": "un",
            "x19": "Win32",
            "x20": "un",
            "x21": "Chrome PDF Plugin,Chrome PDF Viewer,Native Client",
            // "x21": "PDF Viewer,Chrome PDF Viewer,Chromium PDF Viewer,Microsoft Edge PDF Viewer,WebKit built-in PDF",
            "x22": "0ab88f15474a63970784024fa410411b",
            "x23": "false",
            "x24": "false",
            "x25": "false",
            "x26": "false",
            "x27": "false",
            "x28": "0,false,false",
            "x29": "4,7,8",
            "x30": "swf object not loaded",
            "x33": "0",
            "x34": "0",
            "x35": "0",
            "x36": "1",
            "x37": "0|0|0|0|0|0|0|0|0|0",
            "x38": "0|0|0|0|1|0|0|0|0|0|1|0|1|0|1|0",
            "x39": Number(count).toString(),
            "x40": "0",
            "x41": "0",
            "x42": "3.1.0",
            "x43": "0d2c602c",
            "x44": new Date().getTime().toString(),
            // "x44": "1678432890387",
            "x45": "connecterror",
            "x46": "false",
            "x31": "124.04347527516074"
        }
    return postData_encrypt(post_data_json)
}

function test() {
    function test_xsign() {

        let url = "https://www.xiaohongshu.com/fe_api/burdock/v2/shield/profile"
        let ori_x_sign_result = "X8efe40ac90c7df2a07c0c5a1ffa73c41"
        let x_sign_result = x_sign_gen(url)
        console.log(ori_x_sign_result === x_sign_result)
    }

    function test_post_data() {
        // /fe_api/burdock/v2/shield/profile profileData  sdkVersion "3.0.0"
        let post_data_json = {"x1":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36","x2":"false","x3":"zh-CN","x4":"24","x5":"8","x6":"24","x7":"Google Inc. (Google),ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)","x8":"8","x9":"1536;864","x10":"1536;864","x11":"-480","x12":"Asia/Shanghai","x13":"true","x14":"true","x15":"true","x16":"false","x17":"true","x18":"un","x19":"Win32","x20":"un","x21":"Chrome PDF Plugin,Chrome PDF Viewer,Native Client","x22":"0ab88f15474a63970784024fa410411b","x23":"false","x24":"false","x25":"false","x26":"false","x27":"false","x28":"0,false,false","x29":"4,7,8","x30":"swf object not loaded","x33":"0","x34":"0","x35":"0","x36":"3","x37":"0|0|0|0|0|0|0|0|0|0","x38":"0|0|0|0|1|0|0|0|0|0|1|0|1|0|1|0","x39":"9","x40":"0","x41":"0","x42":"3.1.0","x43":"0d2c602c","x44":"1678678896551","x45":"connecterror","x46":"false","x31":"124.04347527516074"}
        let post_data = postData_encrypt(post_data_json)
        console.log(post_data)
    }


    function test_common_gen() {

        let s = "sjvi0gd6sYOBZg1G1iMbZBvCOgZv1i5W1iqkOl9G0Y13"
        let t = 1678261346807
        let a1 = "186a6b43737se48rr6q6eovsjmyzgv0ccw4zuyyqn50000313256"
        let count = 11
        let ret = x_s_common_gen(s, t, a1, count)
        console.log(ret)


    }


    // test_common_gen()
    test_post_data()


}

// test()


// let canvas_info = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAFA3PEY8MlBGQUZaVVBfeMiCeG5uePWvuZHI////////////////////////////////////////////////////2wBDAVVaWnhpeOuCguv/////////////////////////////////////////////////////////////////////////wAARCADIB9ADASIAAhEBAxEB/8QAGQABAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QALBABAAIBAwMBCAMBAQEAAAAAAAECEQMhMRJBUQQUIjJSYXGBkUKhsRMzYv/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EACMRAQEAAgICAgIDAQAAAAAAAAABAhESIQMxQVEEIhMycZH/2gAMAwEAAhEDEQA/AOOI7zwY8Eb1x3TWN8eUoRiVq6eeZiGkVxaMx+U492du68w+2kx+0V06dt07RbEYhP8AOfsfy/C+o10nMYzMwjFecQiu0Vn6GPptlJtb3Y8KTfGMotbecftRMjPLyfS1r57QV1JrxFf0qJ1GV79uiPURjerTGnqRxWXGmszWcxOJVuErO4T4b39Pp9p6Z+6lNLov72JieFtPWjM9fM906nwVllnjqGOWWN7T0U+Wv6Omny1/SlbeV43iIiGGnTMpfSIrT5a/pPRT5a/ox7s/c77ITKdFPlr+jop8tf0mf8RjiSJvR0U+Wv6Ya1ff92Ixjs3x4yx1fixx7q2M7UyvTFOJjsV5TxX8rs1U432iVvm3jc2mc7cJNqccpiInuTE8yR3QERvjO6ExxKBIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6NOnTGZ5lnpVzbM8Q2aYT5a+PH5SIS0aiJjPdICOFNS3aF7TiMsEyMvJlqagAuwAAAAFovPT0zxlURZLNUbxo2mMxNcLTnTpm28R4Z6Or0z0z8M/06piJjE8S58vHGfPLCub2inix7RTxZhqU6LzVGGXCOjna6PaKeLHtFPFnMHCJ510+0U8WY6t4vaJjPHdROCYyIuVqE52wgWVATMYBAAAAAAAJjcEAAAAAAAACYjJjwCBOCYBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOjTjGnH1XREbRA3nTpk1AASBADPUniFFtT4lWkcud3kACoAAAAAA6dC/VXpnmHMtS3ReLeEZTcVym419VXaLfhz42h1+p30cuPPDms7PHf1JI4ySQhomJzEo8J7SieyAxuZ2OxHAHMJmcSjO2IJnKRPcnOPKM7mY7IEJ5lCYnZInzJ23mERJsgTG5E7oz4M75BCeIQnO2JSHYnk7GYQJ/kiMmd8mYwBMoTsTykQniEJkDknwQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHWIr8MfZLodQAACJlFsnsZam15U6k6vxZUU/kt9ObKftU5kzKBXlftCepPUqJmeUNLjXR04tpbxzKt9OaT5jy0w8syuvlTc3pQBqkABtNs+kn6bOZpMzGnMeZhm5s/7GM0AKLJzlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6o2iEg6HUAidoPQTKoOXLLlVlNSM1+zJ0MbV6ZMax8uPyqAsxAAdXp7Z08eJazETGJ4c2h1RS00xM+JPaL+Ksrjd9MbjbekalOi2O3ZVadab4i8RjPZv7PTzZ2YeTc79rXLj7cw6fZ6ebKaunTTpnM57QtziJnKztGNLLJrNrW05mYiIZMc7u7b5fH+ACioAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADqrOaxP0SppTmkfRdvPTpncFbLItW0RmY2nup5LqJVAc6wi1eqMJBFm2ExMTiUN5iLRuytSY+sLysMsLPSoNtHSm09Vo93/S3TK3TXQr06cZ5ndXW0ur3q8/62GO7vbDld7cDt9Nbq0o+mzPW0ur3q8/6ppXnSraZjnhvjlK0v749Oq94pXNpc2+tbrtx2hEdWrbqvx2hq1k37a+Lw67rPW2owa688QyUz9rZ+wBVQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrozvMNnLWemYl0xOYzDXC9abeO9aS6qf+dfs5XToznThl+R/Wf6nP0i2jS3bH2Un00drS3HJyqkysYezf/f9Jj09I5mZbCeVOdZW9PSeMwr7NHzf03DlTnWUen043muZ8yt/zjtK4jdUsmXtn/y+qY048yuG6rwx+lYrEcQx9Tp1nFvrv9XQx9RPwwv4u840wnemIKalumv1d96bW6Y6k9V5VBhXPbsAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADXRv/GfwyEy6qZdXbrbennmv5c2nfqjE8tK26bRPhfOc8dRvf2nTrERMTGY4S89iAAAAAAAAObVnq1J+mzbUt0Vz37OZ0/j498mmE+Rz6luq307Laupn3Y/LJtnlvpXPLfUAFGYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACYnE5htTUi207SwEy6Wxysd+lqdO08f46HmU1Zjad4dOjrxxnMf4z8nj5ftj/AMXusu46hFbRaMxOUuZQAAAARMxWMzwi960558OTV18zvP4hph47l3fSZPtfUv1zmeHPqamdq/tS95t9vCrq3JNROWfxABVmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0prXpOYlvX1s/yrn7OQRZMvad13x6vSnnMfhb2rR+b+pecKfxYm3fb1mnHEWljf1lp2rGHMJmGMNrW1LW5lUF0b2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9k="
let canvas_info = "/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAFA3PEY8MlBGQUZaVVBfeMiCeG5uePWvuZHI////////////////////////////////////////////////////2wBDAVVaWnhpeOuCguv/////////////////////////////////////////////////////////////////////////wAARCADIB9ADASIAAhEBAxEB/8QAGQABAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QALBABAAIBAwMBCAMBAQEAAAAAAAECEQMhMRJBUQQUIjJSYXGBkUKhsRMzYv/EABkBAQADAQEAAAAAAAAAAAAAAAABAgMEBf/EACMRAQEAAgICAgIDAQAAAAAAAAABAhESIQMxQVEEIhMycZH/2gAMAwEAAhEDEQA/AOOI7zwY8Eb1x3TWN8eUoRiVq6eeZiGkVxaMx+U492du68w+2kx+0V06dt07RbEYhP8AOfsfy/C+o10nMYzMwjFecQiu0Vn6GPptlJtb3Y8KTfGMotbecftRMjPLyfS1r57QV1JrxFf0qJ1GV79uiPURjerTGnqRxWXGmszWcxOJVuErO4T4b39Pp9p6Z+6lNLov72JieFtPWjM9fM906nwVllnjqGOWWN7T0U+Wv6Omny1/SlbeV43iIiGGnTMpfSIrT5a/pPRT5a/ox7s/c77ITKdFPlr+jop8tf0mf8RjiSJvR0U+Wv6Ya1ff92Ixjs3x4yx1fixx7q2M7UyvTFOJjsV5TxX8rs1U432iVvm3jc2mc7cJNqccpiInuTE8yR3QERvjO6ExxKBIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6NOnTGZ5lnpVzbM8Q2aYT5a+PH5SIS0aiJjPdICOFNS3aF7TiMsEyMvJlqagAuwAAAAFovPT0zxlURZLNUbxo2mMxNcLTnTpm28R4Z6Or0z0z8M/06piJjE8S58vHGfPLCub2inix7RTxZhqU6LzVGGXCOjna6PaKeLHtFPFnMHCJ510+0U8WY6t4vaJjPHdROCYyIuVqE52wgWVATMYBAAAAAAAJjcEAAAAAAAACYjJjwCBOCYBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOjTjGnH1XREbRA3nTpk1AASBADPUniFFtT4lWkcud3kACoAAAAAA6dC/VXpnmHMtS3ReLeEZTcVym419VXaLfhz42h1+p30cuPPDms7PHf1JI4ySQhomJzEo8J7SieyAxuZ2OxHAHMJmcSjO2IJnKRPcnOPKM7mY7IEJ5lCYnZInzJ23mERJsgTG5E7oz4M75BCeIQnO2JSHYnk7GYQJ/kiMmd8mYwBMoTsTykQniEJkDknwQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHWIr8MfZLodQAACJlFsnsZam15U6k6vxZUU/kt9ObKftU5kzKBXlftCepPUqJmeUNLjXR04tpbxzKt9OaT5jy0w8syuvlTc3pQBqkABtNs+kn6bOZpMzGnMeZhm5s/7GM0AKLJzlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6o2iEg6HUAidoPQTKoOXLLlVlNSM1+zJ0MbV6ZMax8uPyqAsxAAdXp7Z08eJazETGJ4c2h1RS00xM+JPaL+Ksrjd9MbjbekalOi2O3ZVadab4i8RjPZv7PTzZ2YeTc79rXLj7cw6fZ6ebKaunTTpnM57QtziJnKztGNLLJrNrW05mYiIZMc7u7b5fH+ACioAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADqrOaxP0SppTmkfRdvPTpncFbLItW0RmY2nup5LqJVAc6wi1eqMJBFm2ExMTiUN5iLRuytSY+sLysMsLPSoNtHSm09Vo93/S3TK3TXQr06cZ5ndXW0ur3q8/62GO7vbDld7cDt9Nbq0o+mzPW0ur3q8/6ppXnSraZjnhvjlK0v749Oq94pXNpc2+tbrtx2hEdWrbqvx2hq1k37a+Lw67rPW2owa688QyUz9rZ+wBVQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrozvMNnLWemYl0xOYzDXC9abeO9aS6qf+dfs5XToznThl+R/Wf6nP0i2jS3bH2Un00drS3HJyqkysYezf/f9Jj09I5mZbCeVOdZW9PSeMwr7NHzf03DlTnWUen043muZ8yt/zjtK4jdUsmXtn/y+qY048yuG6rwx+lYrEcQx9Tp1nFvrv9XQx9RPwwv4u840wnemIKalumv1d96bW6Y6k9V5VBhXPbsAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADXRv/GfwyEy6qZdXbrbennmv5c2nfqjE8tK26bRPhfOc8dRvf2nTrERMTGY4S89iAAAAAAAAObVnq1J+mzbUt0Vz37OZ0/j498mmE+Rz6luq307Laupn3Y/LJtnlvpXPLfUAFGYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACYnE5htTUi207SwEy6Wxysd+lqdO08f46HmU1Zjad4dOjrxxnMf4z8nj5ftj/AMXusu46hFbRaMxOUuZQAAAARMxWMzwi960558OTV18zvP4hph47l3fSZPtfUv1zmeHPqamdq/tS95t9vCrq3JNROWfxABVmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0prXpOYlvX1s/yrn7OQRZMvad13x6vSnnMfhb2rR+b+pecKfxYm3fb1mnHEWljf1lp2rGHMJmGMNrW1LW5lUF0b2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9k="
let canvas = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCACWASwDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAn/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//9k="


// x_sign_gen()

// x_s_common_gen(
//     "0j461gwvZYZkZjvi0gqBsY5psgACZ2w6OlkBO2sWO6F3",
//     "1678242879743"
// )


/*
canvas
* "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAAAeCAYAAABHenA+AAAAAXNSR0IArs4c6QAADV1JREFUeF7tm3t03VWVxz/ndx9Jbt4PkiZpmkILFVfHLopSkjCBglCqomNF1oiOoAvXyKDM6GpSHRlSZPlg6cJZuGYp4wAygwwPqY4VgYJF+6aV1hZa6FO01bTJTW5yc9+P35l1fskNefzu73fvJWlzl/f8e8/vnH32Pt+9v2fvfQVZDtlFBxobgeqkBt4FEC+evoiu4R9s4ieRMvqkRBeCPW1tPJeaKbtYPtDEy+FKKhDphZCCyEg13z9VzD2rVhHMUtzx6bKL29D40XA9jNSYrxIp5RVvC89LyeH2dv433V6yi0VobI+7afDOh6TbfGagmo1DDeyVkv6BAR654QZCucpvIcuHEDyFoKS/BaKl5jOlRtDbwkMxD73JJE93dHDcShb5Fa5LaGzwtlKaSHM+BDJUwUsD83isvZ3/numzTVxPruM/gc8Zd64V4kXTd5MQH67nyUANxzPRufwSNbjZHHezLJ0dk07O9LfyaNxJr5Q83tFB3zs5p8VVNznQWupx8Dxwifp1sAFCVWACGD1YzfO+BvaMrfJnv5/HpwImehffHJzPVxJFVpCDpJPewRrWLf8g/5PrYWcDcBEPDYPzQdesAZdM8sYVV/BkrrKnBdt6igkbTuyqWBEMtBi6Mh0TAfedV459yxdZZClOiRzhu/5rqJu3h0h5+qkBUcUvnZ9nl/dz+KIXzPQRjfUuTOzlvpFVVEovoQrwzQNponOv1sSmoltI4KY3+B4OeddMkmfzOjHpvs9pwEkFq27uR3AnoAUrYajB/ODxIg73t/JTXSMBhlff2NbGG1OtIbspD1Szdfg8lkmHha0EMlrMjv5W7mxrY28uVj0XgAuX8duB+fxGCHZcfjmbcpHbMgqt4w4k30PgUlF7uE5ZZmYAp1a5JdTDR4rvJdAgkRau+ah2CU9Hezjs+8hMHxGXjPD1wBoui4+SI28LRNJE8decf8s+19Xo0slR3/s5NXJ5HgOuiw+MUZdS5U2VZ0+4puvXjkpOA10XHYrGRcoos6SWEA/W8nB/Ffd0dtKbrWVnGHDz0PhtxMNFVhEu4eIPZ87nJzjYOtOAk2tZisZzCOYrmtW/ABIm1D6lp2wjnPpuXvIPfCfciWg+RdKEwqXW1tHYpX2YJ333MxQ9P1vTpJ8vJf8U+jIfjT6Ahj4a3ZSTN3HOQVHJC0W3oiJuMF7D78/8A5FkdX4CTn6NZuL8GsESqajkfAgrLzPd62VEJadqOLKe+3yNdCXc1tRSd+AdauTun23nwfXr0bOx7IwC7osU4WFTxEOnFeCkIDo0j8eDlfyyrY0N2chrGdm6WYLgF8BFap5iGgFzaj++TOp9E6zlYCaUMvWhinKrq+8lWmFwnLQjiZNtiZt5eOAREGnCbDYKkJJPRL7NreEenMSxyhdIBAecnex3XWXscCa0lNf7b5y2W15QSqkuVwlPIPg7dQJFXfznYUox4m6O9S/kSTsqOS3KdVM+Usc2fy3vMePmE+fHi3jt9EI+397OjqzsN4NJE7Wv7GZ9rIQebzPoJpE+JVvCzVt9C7m/b5CHZiJpItfShoMngAVqj3AZ+BpBt6LkSt6xhEK2gKvS+/hWopOyxsO2e+hSY1fok/wo8DC6SPOYzMBoikaqyPah6INGZLNx8vi0el50f5qIKCWW9BhgM3tP5gfgJrwTYiXgbTK/YLrGyGATj6XLStrpWXZzjbeZX0TK8VjHOfRQGT8fbuVfLruMk3brjlOqmQbcOq5Iajzb30pFwoJuqUxe3M2B/npuX/F+dmYq7zSntB4nIdYhuAswyKNiGSqBYAX48fML4sN1PBWo5c0f7Nt579T3jZVcl8V+xZ3la0hWRC2jnLGGFHj9F/PvoWc46XhX1se9IHGA7uCtXJjcN7qciuCNEKwwZVTERRFbXDfyZ8diVKQ7HVjKoYGPme475wE39Z2gsmAKdCZDUclNvgZeMZQk6R0Z4bFs0/iRHr7va+IOW2qp4R+u5bsbfsc3MqWWM0kpjTOORv5nB5u4JlSZwb1KcqKsnxurv8roTcpwSJWJDHEr8G8ImlKfqaSVKnHYRbaJ24yVKXZnCzhl0C8k/pEV9f+F7lIQsBkSivwOjg6u5rGiuznseC9MThBOWkCTCZYmdvDJ8DdYnnjJiGpqKBrpaxpLkpjQ2alUMpyo5EDf3xOIN+Yf4AxDh413x2olvdU7YQqVDMfjbOzs5JCdXab+rtK0/ka2jdRysS21dHN0YD5r33el8ZaxHTMNOAN0XXwgUM1PhxsosZNXueqiMMnqU7zs1HmAGNvF9xg0E1z+Kw0kuQa4CbgW8KTmqX189RCunEDrBVLXGNKSqDiQllyOZU1f+uG+HfeeHGmz1dnECYrm3e28ltaabZYZy/FvJDhjUKmqVsEyjjuX8SfHxRx3LDOmOEhwYeJVFiYP0pp8AzeRSfKEysFfb56YM3SP4E3nCva4Vo2CU7o47rsaq3PN6Qgnu+lC8G2VaLZ6J0ylklLyakcHz2ZlzQmTDWo5n42RMkosqaVAhj08N9DCWrOSwzQwzzClHDU6Iv5VHhhs5Y64TS0xJY8zOnoJS1QJXxJHMIQ0mJMaGgJVlp+WdVDefqRulFrJyc8jPVLKznAFR6pO8wkhR+mm2YgVcajvfJ5+5LUXeo75rsvaRCX6MF+rXElL8T57ajnuIcAVgTIfePzWnylnojKRKgFkFLbTJGkU2I45L+EV12p0nLZUMiXKnAWcuvQII7pVWGWHgBmhklMtH/o6/zHUwO1Jm6ylygIGKvnBSQ932dHX2YhwBujWUj/cwG8CKipn2kYgwRWFEj+UBMAVSwsQwuWj3SOqm2fq+irVP1LDr/x1HHKHqag7yWdccapUId5MlqSTvv5Wfvzo0We6pxaFM0VfiRigq+qDXODarZ6nmX42Ok8HZxwc8dHoZwwB6g2cdI0W7e10qEoQB50dRr1t1OkJvKElHOi7yTY7OicBpy5Qht0kzBSVnBaN1lLvr2fLSC1L7Khapl0oswU4JXvgn2kIvovtsSIW2SR8zC+oCpX6288cKccaCtIBWCATLk54W9iQcI22i4kkYuEBPl46xMXDaRoSUpnKR/sf+tTeM5/NDiwTZhdrg3y6+nZWOH5mpOzP1giJcna4PsxfHIvHwTYYXsRB70eJ62mq4ROEm3OAm9pNokK7epibXfqZppLTQLeO1d5mnsmEWkaL2dm3gC+1t7M7nfFnE3Bqz4NPsbg0xBMOWG643VkausZwoIYX/XUcTG0hBBFdZ2fbz1kZ9dAzoEoVabLyUQ97fxy/f/n+MzcTTDTkLKVLC3Jl7QNcp/2Qenky+2iXxc6qxnfE+V72uVYabVtGsJQa/eF383rfGtvIltpq7gEuw26S2aKSE22gwB+6hwf9jdyWcFlfYOW57bpQZhtwSvYtW2g8r49veoJ8TNOx6EDM4raNTVVAC1UZbXD7pBgv+kspOR2N8n8rV3JaZlCqUOtscH25ct/Qx6e1PmUtldRZUvMsbZ7HuTTxIuVycEaBp+jjKccSfue6loB4u2sklizhreFOywSJ2VnmFOCy6CaZNSppRi2HG9gaqOEiO2pp14VyNgCn5N+6lWq3gzXl/dxQOkyHplOba8RTb1RVOA/UsD1YOa3mqKjk7hdeYEuqNJJRqUIg9zuuFJsTt/H7vk9ljTGzD2pLDrO46kUWOA8Y6f1m/RguGc1pbUUOFLiOOC/lqGM5MfF2DkjHwUDoQo4MrprWtpXJZnMKcBMF3rGDdiFQr1LLdgH1t5t3mpW0U9T69WjXX89NUrIkfd5qfJWElGy26kLZtYvrpKTdal+7v+dkIvOqVXTqOivcSWpKh1hcFGKxM0aT0PGMZRLfzkQKVekiKjXCKrERL+ZPwUrejHpMywYhKdlfUcHLS5dimm7ZupVLnU6uB0x7YDb/safHqiPD7nymv0udhZXbaC7fQ5FjhAoGaU4eY57+FtX6adxEccvwpAioIpgCVEhUMKA18RdtkVHATtHG1D6KPvpjzZwYugq7fzlYyT4VcKm527dTLwQ3C4FqkDM/nmRoVv6es3s3LfE4N2maPSXKtcCdrUEVVXO7DdBN7kY1WUjXGXG5eCpdF8rZAFxKrNdfxx0IcKWU/A0Y+sz1bacyE2eUc9u0if12xf6NG/HU1XELYPpIU4Cz68rI1kbj86VOQ+lrNJe/SkVRLw6RW1JFyRdLlNIfvoiT/jZCifNyFin14ZwE3Ds+VWEBUw0oLwos1TSjB7JGSlSlySXEpJqbyrPHhSCWTDIsJWc0jUObNnHCDmTZqP3q+1RAPQtD6tSUnKDOc4Rydy8epw8h4ji12ORIJzWjcJ3QPYTiNQxFF9AbWEY0mTbg5CR8OsDltFiOH+XqcXPcrvDZXNDAWQPcXDjsBBkKgJtjBvlrEacAuHNn6UKEO3e6P2c7FwB3zlSf8yP+3Elc2LmggTzWQCHC5bHxCqLnnwYKgMs/mxUkzmMNFACXx8YriJ5/GigALv9sVpA4jzVQAFweG68gev5poAC4/LNZQeI81kABcHlsvILo+aeBAuDyz2YFifNYA/8P1mFjiA1grRYAAAAASUVORK5CYII="
* "iVBORw0KGgoAAAANSUhEUgAAANwAAAAeCAYAAABHenA+AAAAAXNSR0IArs4c6QAADV1JREFUeF7tm3t03VWVxz/ndx9Jbt4PkiZpmkILFVfHLopSkjCBglCqomNF1oiOoAvXyKDM6GpSHRlSZPlg6cJZuGYp4wAygwwPqY4VgYJF+6aV1hZa6FO01bTJTW5yc9+P35l1fskNefzu73fvJWlzl/f8e8/vnH32Pt+9v2fvfQVZDtlFBxobgeqkBt4FEC+evoiu4R9s4ieRMvqkRBeCPW1tPJeaKbtYPtDEy+FKKhDphZCCyEg13z9VzD2rVhHMUtzx6bKL29D40XA9jNSYrxIp5RVvC89LyeH2dv433V6yi0VobI+7afDOh6TbfGagmo1DDeyVkv6BAR654QZCucpvIcuHEDyFoKS/BaKl5jOlRtDbwkMxD73JJE93dHDcShb5Fa5LaGzwtlKaSHM+BDJUwUsD83isvZ3/numzTVxPruM/gc8Zd64V4kXTd5MQH67nyUANxzPRufwSNbjZHHezLJ0dk07O9LfyaNxJr5Q83tFB3zs5p8VVNznQWupx8Dxwifp1sAFCVWACGD1YzfO+BvaMrfJnv5/HpwImehffHJzPVxJFVpCDpJPewRrWLf8g/5PrYWcDcBEPDYPzQdesAZdM8sYVV/BkrrKnBdt6igkbTuyqWBEMtBi6Mh0TAfedV459yxdZZClOiRzhu/5rqJu3h0h5+qkBUcUvnZ9nl/dz+KIXzPQRjfUuTOzlvpFVVEovoQrwzQNponOv1sSmoltI4KY3+B4OeddMkmfzOjHpvs9pwEkFq27uR3AnoAUrYajB/ODxIg73t/JTXSMBhlff2NbGG1OtIbspD1Szdfg8lkmHha0EMlrMjv5W7mxrY28uVj0XgAuX8duB+fxGCHZcfjmbcpHbMgqt4w4k30PgUlF7uE5ZZmYAp1a5JdTDR4rvJdAgkRau+ah2CU9Hezjs+8hMHxGXjPD1wBoui4+SI28LRNJE8decf8s+19Xo0slR3/s5NXJ5HgOuiw+MUZdS5U2VZ0+4puvXjkpOA10XHYrGRcoos6SWEA/W8nB/Ffd0dtKbrWVnGHDz0PhtxMNFVhEu4eIPZ87nJzjYOtOAk2tZisZzCOYrmtW/ABIm1D6lp2wjnPpuXvIPfCfciWg+RdKEwqXW1tHYpX2YJ333MxQ9P1vTpJ8vJf8U+jIfjT6Ahj4a3ZSTN3HOQVHJC0W3oiJuMF7D78/8A5FkdX4CTn6NZuL8GsESqajkfAgrLzPd62VEJadqOLKe+3yNdCXc1tRSd+AdauTun23nwfXr0bOx7IwC7osU4WFTxEOnFeCkIDo0j8eDlfyyrY0N2chrGdm6WYLgF8BFap5iGgFzaj++TOp9E6zlYCaUMvWhinKrq+8lWmFwnLQjiZNtiZt5eOAREGnCbDYKkJJPRL7NreEenMSxyhdIBAecnex3XWXscCa0lNf7b5y2W15QSqkuVwlPIPg7dQJFXfznYUox4m6O9S/kSTsqOS3KdVM+Usc2fy3vMePmE+fHi3jt9EI+397OjqzsN4NJE7Wv7GZ9rIQebzPoJpE+JVvCzVt9C7m/b5CHZiJpItfShoMngAVqj3AZ+BpBt6LkSt6xhEK2gKvS+/hWopOyxsO2e+hSY1fok/wo8DC6SPOYzMBoikaqyPah6INGZLNx8vi0el50f5qIKCWW9BhgM3tP5gfgJrwTYiXgbTK/YLrGyGATj6XLStrpWXZzjbeZX0TK8VjHOfRQGT8fbuVfLruMk3brjlOqmQbcOq5Iajzb30pFwoJuqUxe3M2B/npuX/F+dmYq7zSntB4nIdYhuAswyKNiGSqBYAX48fML4sN1PBWo5c0f7Nt579T3jZVcl8V+xZ3la0hWRC2jnLGGFHj9F/PvoWc46XhX1se9IHGA7uCtXJjcN7qciuCNEKwwZVTERRFbXDfyZ8diVKQ7HVjKoYGPme475wE39Z2gsmAKdCZDUclNvgZeMZQk6R0Z4bFs0/iRHr7va+IOW2qp4R+u5bsbfsc3MqWWM0kpjTOORv5nB5u4JlSZwb1KcqKsnxurv8roTcpwSJWJDHEr8G8ImlKfqaSVKnHYRbaJ24yVKXZnCzhl0C8k/pEV9f+F7lIQsBkSivwOjg6u5rGiuznseC9MThBOWkCTCZYmdvDJ8DdYnnjJiGpqKBrpaxpLkpjQ2alUMpyo5EDf3xOIN+Yf4AxDh413x2olvdU7YQqVDMfjbOzs5JCdXab+rtK0/ka2jdRysS21dHN0YD5r33el8ZaxHTMNOAN0XXwgUM1PhxsosZNXueqiMMnqU7zs1HmAGNvF9xg0E1z+Kw0kuQa4CbgW8KTmqX189RCunEDrBVLXGNKSqDiQllyOZU1f+uG+HfeeHGmz1dnECYrm3e28ltaabZYZy/FvJDhjUKmqVsEyjjuX8SfHxRx3LDOmOEhwYeJVFiYP0pp8AzeRSfKEysFfb56YM3SP4E3nCva4Vo2CU7o47rsaq3PN6Qgnu+lC8G2VaLZ6J0ylklLyakcHz2ZlzQmTDWo5n42RMkosqaVAhj08N9DCWrOSwzQwzzClHDU6Iv5VHhhs5Y64TS0xJY8zOnoJS1QJXxJHMIQ0mJMaGgJVlp+WdVDefqRulFrJyc8jPVLKznAFR6pO8wkhR+mm2YgVcajvfJ5+5LUXeo75rsvaRCX6MF+rXElL8T57ajnuIcAVgTIfePzWnylnojKRKgFkFLbTJGkU2I45L+EV12p0nLZUMiXKnAWcuvQII7pVWGWHgBmhklMtH/o6/zHUwO1Jm6ylygIGKvnBSQ932dHX2YhwBujWUj/cwG8CKipn2kYgwRWFEj+UBMAVSwsQwuWj3SOqm2fq+irVP1LDr/x1HHKHqag7yWdccapUId5MlqSTvv5Wfvzo0We6pxaFM0VfiRigq+qDXODarZ6nmX42Ok8HZxwc8dHoZwwB6g2cdI0W7e10qEoQB50dRr1t1OkJvKElHOi7yTY7OicBpy5Qht0kzBSVnBaN1lLvr2fLSC1L7Khapl0oswU4JXvgn2kIvovtsSIW2SR8zC+oCpX6288cKccaCtIBWCATLk54W9iQcI22i4kkYuEBPl46xMXDaRoSUpnKR/sf+tTeM5/NDiwTZhdrg3y6+nZWOH5mpOzP1giJcna4PsxfHIvHwTYYXsRB70eJ62mq4ROEm3OAm9pNokK7epibXfqZppLTQLeO1d5mnsmEWkaL2dm3gC+1t7M7nfFnE3Bqz4NPsbg0xBMOWG643VkausZwoIYX/XUcTG0hBBFdZ2fbz1kZ9dAzoEoVabLyUQ97fxy/f/n+MzcTTDTkLKVLC3Jl7QNcp/2Qenky+2iXxc6qxnfE+V72uVYabVtGsJQa/eF383rfGtvIltpq7gEuw26S2aKSE22gwB+6hwf9jdyWcFlfYOW57bpQZhtwSvYtW2g8r49veoJ8TNOx6EDM4raNTVVAC1UZbXD7pBgv+kspOR2N8n8rV3JaZlCqUOtscH25ct/Qx6e1PmUtldRZUvMsbZ7HuTTxIuVycEaBp+jjKccSfue6loB4u2sklizhreFOywSJ2VnmFOCy6CaZNSppRi2HG9gaqOEiO2pp14VyNgCn5N+6lWq3gzXl/dxQOkyHplOba8RTb1RVOA/UsD1YOa3mqKjk7hdeYEuqNJJRqUIg9zuuFJsTt/H7vk9ljTGzD2pLDrO46kUWOA8Y6f1m/RguGc1pbUUOFLiOOC/lqGM5MfF2DkjHwUDoQo4MrprWtpXJZnMKcBMF3rGDdiFQr1LLdgH1t5t3mpW0U9T69WjXX89NUrIkfd5qfJWElGy26kLZtYvrpKTdal+7v+dkIvOqVXTqOivcSWpKh1hcFGKxM0aT0PGMZRLfzkQKVekiKjXCKrERL+ZPwUrejHpMywYhKdlfUcHLS5dimm7ZupVLnU6uB0x7YDb/safHqiPD7nymv0udhZXbaC7fQ5FjhAoGaU4eY57+FtX6adxEccvwpAioIpgCVEhUMKA18RdtkVHATtHG1D6KPvpjzZwYugq7fzlYyT4VcKm527dTLwQ3C4FqkDM/nmRoVv6es3s3LfE4N2maPSXKtcCdrUEVVXO7DdBN7kY1WUjXGXG5eCpdF8rZAFxKrNdfxx0IcKWU/A0Y+sz1bacyE2eUc9u0if12xf6NG/HU1XELYPpIU4Cz68rI1kbj86VOQ+lrNJe/SkVRLw6RW1JFyRdLlNIfvoiT/jZCifNyFin14ZwE3Ds+VWEBUw0oLwos1TSjB7JGSlSlySXEpJqbyrPHhSCWTDIsJWc0jUObNnHCDmTZqP3q+1RAPQtD6tSUnKDOc4Rydy8epw8h4ji12ORIJzWjcJ3QPYTiNQxFF9AbWEY0mTbg5CR8OsDltFiOH+XqcXPcrvDZXNDAWQPcXDjsBBkKgJtjBvlrEacAuHNn6UKEO3e6P2c7FwB3zlSf8yP+3Elc2LmggTzWQCHC5bHxCqLnnwYKgMs/mxUkzmMNFACXx8YriJ5/GigALv9sVpA4jzVQAFweG68gev5poAC4/LNZQeI81kABcHlsvILo+aeBAuDyz2YFifNYA/8P1mFjiA1grRYAAAAASUVORK5CYII="

*
* */

// console.log(mk_list)

/*
* "位置 1", "args", args, "ref", ref, "值func: ",func,func.name+"()","_ace_88205:",_ace_88205 ,"_ace_c59cd:",_ace_c59cd
*
*
*
* */
// "位置 1",JSON.stringify(
//     {"args" : args, "ref":ref , "funName" : func, "_ace_c59cd" : _ace_c59cd },
//     function(key, value) {
//         if (typeof  value == "function"){
//             return value.name
//         }
//         if (value == window) {
//             return undefined
//         }
//
//         return value
//     }
// )
// "位置 1",JSON.stringify(
//     {"args" : args, "ref":ref , "funName" : func, "_ace_c59cd" : _ace_c59cd },
//     function(key, value) {
//         if (typeof  value == "function"){
//             return value.name
//         }
//         if (value == window) {
//             return undefined
//         }
//
//         return value
//     }
// )

/*
*
* "位置 1", "args", args, "ref", ref, "值func: ",func,func.name+"()","_ace_88205:",_ace_88205 ,"_ace_c59cd:",_ace_c59cd[0]
* "位置 1", "args", args, "ref", ref, "值func: ",func,func.name+"()","_ace_c59cd:",_ace_c59cd[0]
*
*
* 调用位 : "_ace_880c:",_ace_880c , "_ace_2abd9:" _ace_2abd9, "funIndex : " ,_ace_6a7a9[_ace_99beb]
*
* */

let enable_server = true
if (enable_server){

    app.get('/gen_web_id', (req, res) => {
        let web_info_obj = gen_web_id()
        console.log(web_info_obj)
        res.json(web_info_obj)

    })


    app.get('/gen_postData', (req, res) => {

        let profile_count = req.query.count
        let postData;
        if (profile_count){

            postData = gen_postData(parseInt(profile_count))

        }else{
            postData = gen_postData()
        }

        res.send(postData)

    })


    app.get("/gen_xsign",(req,res) =>{
        let url = req.query.url
        let xsign = x_sign_gen(url)
        res.send(xsign)

    })


    app.get("/gen_xcommon",(req,res) =>{
        let s = req.query.s
        let t = parseInt(req.query.t)
        let a1 = req.query.a1
        let count = parseInt(req.query.count)

        let x_common = x_s_common_gen(s,t,a1,count)

        res.send(x_common)

    })



     // app.listen(port, () => {
     //        console.log(`Example app listening at http://localhost:${port}`)
     //    })

    app.listen(port, () => {
            console.log(`Example app listening at http://localhost:${port}`)
        })

}


